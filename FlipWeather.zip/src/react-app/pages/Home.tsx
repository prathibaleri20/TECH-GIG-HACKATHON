import { useOrientation } from '@/react-app/hooks/useOrientation';
import AlarmClock from '@/react-app/components/AlarmClock';
import Stopwatch from '@/react-app/components/Stopwatch';
import Timer from '@/react-app/components/Timer';
import Weather from '@/react-app/components/Weather';

export default function Home() {
  const orientation = useOrientation();

  const renderComponent = () => {
    switch (orientation) {
      case 'portrait-up':
        return <AlarmClock />;
      case 'portrait-down':
        return <Timer />;
      case 'landscape-right':
        return <Stopwatch />;
      case 'landscape-left':
        return <Weather />;
      default:
        return <AlarmClock />;
    }
  };

  return (
    <div className="transition-all duration-700 ease-in-out transform">
      <div className="animate-fade-in">
        {renderComponent()}
      </div>
    </div>
  );
}
