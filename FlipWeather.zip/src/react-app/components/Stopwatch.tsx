import { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Flag } from 'lucide-react';

interface Lap {
  id: number;
  time: number;
  splitTime: number;
}

export default function Stopwatch() {
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [laps, setLaps] = useState<Lap[]>([]);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = window.setInterval(() => {
        setTime(prevTime => prevTime + 10);
      }, 10);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning]);

  const formatTime = (milliseconds: number) => {
    const minutes = Math.floor(milliseconds / 60000);
    const seconds = Math.floor((milliseconds % 60000) / 1000);
    const centiseconds = Math.floor((milliseconds % 1000) / 10);
    
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${centiseconds.toString().padStart(2, '0')}`;
  };

  const toggleStopwatch = () => {
    setIsRunning(!isRunning);
  };

  const resetStopwatch = () => {
    setIsRunning(false);
    setTime(0);
    setLaps([]);
  };

  const addLap = () => {
    if (time > 0) {
      const lapTime = laps.length > 0 ? time - laps[laps.length - 1].time : time;
      const newLap: Lap = {
        id: laps.length + 1,
        time: time,
        splitTime: lapTime
      };
      setLaps(prev => [...prev, newLap]);
    }
  };

  const getFastestLap = () => {
    if (laps.length === 0) return null;
    return Math.min(...laps.map(lap => lap.splitTime));
  };

  const getSlowestLap = () => {
    if (laps.length === 0) return null;
    return Math.max(...laps.map(lap => lap.splitTime));
  };

  const fastestTime = getFastestLap();
  const slowestTime = getSlowestLap();

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-900 via-teal-900 to-cyan-900 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent mb-8">
            Stopwatch
          </h1>
          
          <div className="text-8xl font-mono font-bold mb-8">
            {formatTime(time)}
          </div>

          <div className="flex items-center justify-center space-x-6">
            <button
              onClick={resetStopwatch}
              className="p-4 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            >
              <RotateCcw className="w-8 h-8" />
            </button>
            
            <button
              onClick={toggleStopwatch}
              className="p-6 rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 transition-all transform hover:scale-105"
            >
              {isRunning ? <Pause className="w-10 h-10" /> : <Play className="w-10 h-10" />}
            </button>
            
            <button
              onClick={addLap}
              disabled={time === 0}
              className="p-4 rounded-full bg-white/10 hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Flag className="w-8 h-8" />
            </button>
          </div>
        </div>

        {laps.length > 0 && (
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
            <h2 className="text-2xl font-semibold mb-4 text-center">Lap Times</h2>
            <div className="max-h-80 overflow-y-auto space-y-2">
              {laps.map((lap) => {
                const isFastest = fastestTime !== null && lap.splitTime === fastestTime && laps.length > 1;
                const isSlowest = slowestTime !== null && lap.splitTime === slowestTime && laps.length > 1;
                
                return (
                  <div
                    key={lap.id}
                    className={`flex justify-between items-center p-3 rounded-lg ${
                      isFastest ? 'bg-green-500/20 border border-green-400/30' :
                      isSlowest ? 'bg-red-500/20 border border-red-400/30' :
                      'bg-white/5'
                    }`}
                  >
                    <span className="font-semibold">Lap {lap.id}</span>
                    <div className="text-right">
                      <div className="font-mono text-lg">
                        {formatTime(lap.splitTime)}
                        {isFastest && <span className="text-green-400 ml-2">↑</span>}
                        {isSlowest && <span className="text-red-400 ml-2">↓</span>}
                      </div>
                      <div className="font-mono text-sm text-white/60">
                        Total: {formatTime(lap.time)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div className="mt-8 text-center">
          <p className="text-white/60 text-sm">
            Flip upside down for weather
          </p>
        </div>
      </div>
    </div>
  );
}
