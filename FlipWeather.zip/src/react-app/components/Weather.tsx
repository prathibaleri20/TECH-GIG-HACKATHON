import { useWeather } from '@/react-app/hooks/useWeather';
import { RefreshCw, MapPin, Thermometer, Wind, Droplets } from 'lucide-react';

export default function Weather() {
  const { weather, loading, error, refetch } = useWeather();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white">
        <div className="text-center space-y-4">
          <div className="animate-spin">
            <RefreshCw className="w-12 h-12 mx-auto" />
          </div>
          <p className="text-xl">Loading weather...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-red-600 via-red-700 to-red-800 text-white">
        <div className="text-center space-y-4 p-8">
          <p className="text-xl">Failed to load weather</p>
          <p className="text-white/80">{error}</p>
          <button
            onClick={refetch}
            className="px-6 py-3 bg-white/20 hover:bg-white/30 rounded-lg transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  if (!weather) return null;

  const getWeatherIcon = (icon: string) => {
    return `https://openweathermap.org/img/wn/${icon}@4x.png`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-200 to-white bg-clip-text text-transparent">
            Weather Today
          </h1>
          <button
            onClick={refetch}
            className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
          >
            <RefreshCw className="w-6 h-6" />
          </button>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Main Weather Card */}
          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20">
            <div className="flex items-center space-x-4 mb-6">
              <MapPin className="w-6 h-6 text-blue-300" />
              <div>
                <h2 className="text-2xl font-semibold">{weather.location}</h2>
                <p className="text-white/70">{weather.country}</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-7xl font-bold mb-2">
                  {weather.temperature}°
                </div>
                <p className="text-xl text-white/80 capitalize">
                  {weather.description}
                </p>
                <p className="text-white/60 mt-2">
                  Feels like {weather.feelsLike}°
                </p>
              </div>
              <div className="text-right">
                <img
                  src={getWeatherIcon(weather.icon)}
                  alt={weather.description}
                  className="w-32 h-32"
                />
              </div>
            </div>
          </div>

          {/* Weather Details */}
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20">
              <div className="flex items-center space-x-4">
                <div className="p-3 rounded-full bg-blue-500/30">
                  <Thermometer className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-white/70">Temperature</p>
                  <p className="text-2xl font-semibold">{weather.temperature}°C</p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20">
              <div className="flex items-center space-x-4">
                <div className="p-3 rounded-full bg-green-500/30">
                  <Droplets className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-white/70">Humidity</p>
                  <p className="text-2xl font-semibold">{weather.humidity}%</p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20">
              <div className="flex items-center space-x-4">
                <div className="p-3 rounded-full bg-purple-500/30">
                  <Wind className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-white/70">Wind Speed</p>
                  <p className="text-2xl font-semibold">{weather.windSpeed} m/s</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-white/60 text-sm">
            Flip right-side up for stopwatch
          </p>
        </div>
      </div>
    </div>
  );
}
