import { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Plus, Minus, Bell } from 'lucide-react';

export default function Timer() {
  const [minutes, setMinutes] = useState(5);
  const [seconds, setSeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [initialTime, setInitialTime] = useState(5 * 60);
  const [isComplete, setIsComplete] = useState(false);
  const intervalRef = useRef<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const totalSeconds = minutes * 60 + seconds;

  useEffect(() => {
    if (isRunning && totalSeconds > 0) {
      intervalRef.current = window.setInterval(() => {
        setSeconds(prev => {
          if (prev > 0) {
            return prev - 1;
          } else if (minutes > 0) {
            setMinutes(m => m - 1);
            return 59;
          } else {
            setIsRunning(false);
            setIsComplete(true);
            // Play completion sound
            if (!audioRef.current) {
              audioRef.current = new Audio('data:audio/wav;base64,UklGRhIFAABXQVZFZm10IBAAAAABAAEAESsAABErAAABAAgAZGF0YXoEAABhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFi');
            }
            audioRef.current.play().catch(() => {
              console.log('Timer complete!');
            });
            return 0;
          }
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, minutes, totalSeconds]);

  const toggleTimer = () => {
    if (isComplete) {
      resetTimer();
    } else {
      setIsRunning(!isRunning);
    }
  };

  const resetTimer = () => {
    setIsRunning(false);
    setIsComplete(false);
    const resetMinutes = Math.floor(initialTime / 60);
    const resetSeconds = initialTime % 60;
    setMinutes(resetMinutes);
    setSeconds(resetSeconds);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  const dismissComplete = () => {
    setIsComplete(false);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  const adjustTime = (delta: number) => {
    if (isRunning || isComplete) return;
    const newTime = Math.max(60, initialTime + delta);
    setInitialTime(newTime);
    setMinutes(Math.floor(newTime / 60));
    setSeconds(newTime % 60);
  };

  const progress = initialTime > 0 ? ((initialTime - totalSeconds) / initialTime) * 100 : 0;

  const formatTime = (mins: number, secs: number) => {
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (isComplete) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-green-600 via-emerald-700 to-teal-800 text-white p-8 animate-pulse">
        <div className="text-center space-y-8">
          <div className="animate-bounce">
            <Bell className="w-24 h-24 mx-auto text-yellow-300" />
          </div>
          <h1 className="text-6xl font-bold">TIME'S UP!</h1>
          <p className="text-2xl">Timer completed</p>
          <div className="space-y-4">
            <button
              onClick={dismissComplete}
              className="px-8 py-4 bg-white text-green-600 rounded-full text-xl font-semibold hover:bg-gray-100 transition-colors mr-4"
            >
              Dismiss
            </button>
            <button
              onClick={resetTimer}
              className="px-8 py-4 bg-white/20 text-white rounded-full text-xl font-semibold hover:bg-white/30 transition-colors"
            >
              Reset Timer
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800 text-white p-8">
      <div className="text-center space-y-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          Timer
        </h1>
        
        <div className="relative">
          <div className="w-64 h-64 rounded-full border-8 border-white/20 flex items-center justify-center relative overflow-hidden">
            <div 
              className="absolute inset-0 rounded-full transition-all duration-1000 ease-in-out"
              style={{
                background: `conic-gradient(from 0deg, rgba(99, 102, 241, 0.8) 0%, rgba(99, 102, 241, 0.8) ${progress}%, transparent ${progress}%, transparent 100%)`
              }}
            />
            <div className={`text-6xl font-mono font-bold z-10 transition-all duration-300 ${
              totalSeconds <= 10 && isRunning ? 'text-red-400 animate-pulse' : ''
            }`}>
              {formatTime(minutes, seconds)}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-center space-x-4">
          <button
            onClick={() => adjustTime(-60)}
            disabled={isRunning || isComplete}
            className="p-3 rounded-full bg-white/10 hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 hover:scale-105"
          >
            <Minus className="w-6 h-6" />
          </button>
          
          <button
            onClick={toggleTimer}
            className="p-4 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 transition-all duration-200 transform hover:scale-105 active:scale-95"
          >
            {isRunning ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
          </button>
          
          <button
            onClick={() => adjustTime(60)}
            disabled={isRunning || isComplete}
            className="p-3 rounded-full bg-white/10 hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 hover:scale-105"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>

        <button
          onClick={resetTimer}
          className="flex items-center space-x-2 px-6 py-3 rounded-full bg-white/10 hover:bg-white/20 transition-all duration-200 hover:scale-105"
        >
          <RotateCcw className="w-5 h-5" />
          <span>Reset</span>
        </button>

        {totalSeconds <= 10 && isRunning && totalSeconds > 0 && (
          <div className="text-red-400 text-lg font-semibold animate-pulse">
            Final countdown!
          </div>
        )}

        <p className="text-white/60 text-sm">
          Flip right-side up for alarm
        </p>
      </div>
    </div>
  );
}
