import { useState, useEffect, useRef } from 'react';
import { Bell, BellOff, Plus, Minus, Clock, Volume2 } from 'lucide-react';

export default function AlarmClock() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [alarmTime, setAlarmTime] = useState<string>('07:00');
  const [isAlarmEnabled, setIsAlarmEnabled] = useState(false);
  const [isRinging, setIsRinging] = useState(false);
  const [snoozeCount, setSnoozeCount] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (isAlarmEnabled && !isRinging) {
      const now = new Date();
      const [alarmHours, alarmMinutes] = alarmTime.split(':').map(Number);
      const alarm = new Date();
      alarm.setHours(alarmHours, alarmMinutes, 0, 0);

      // If alarm time has passed today, set for tomorrow
      if (alarm <= now) {
        alarm.setDate(alarm.getDate() + 1);
      }

      const timeUntilAlarm = alarm.getTime() - now.getTime();
      
      if (timeUntilAlarm <= 1000) { // Within 1 second
        setIsRinging(true);
        // Create enhanced audio for alarm
        if (!audioRef.current) {
          audioRef.current = new Audio('data:audio/wav;base64,UklGRhIFAABXQVZFZm10IBAAAAABAAEAESsAABErAAABAAgAZGF0YXoEAABhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFiYWJhYmFi');
          audioRef.current.loop = true;
        }
        audioRef.current.play().catch(() => {
          console.log('Alarm ringing!');
        });
      }
    }
  }, [currentTime, alarmTime, isAlarmEnabled, isRinging]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit',
      hour12: false 
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString([], { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const adjustAlarmTime = (minutes: number) => {
    const [hours, mins] = alarmTime.split(':').map(Number);
    const totalMinutes = hours * 60 + mins + minutes;
    const newHours = Math.floor((totalMinutes % 1440) / 60);
    const newMins = totalMinutes % 60;
    setAlarmTime(`${newHours.toString().padStart(2, '0')}:${newMins.toString().padStart(2, '0')}`);
  };

  const stopAlarm = () => {
    setIsRinging(false);
    setIsAlarmEnabled(false);
    setSnoozeCount(0);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  const snoozeAlarm = () => {
    setIsRinging(false);
    setSnoozeCount(prev => prev + 1);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    // Set alarm for 9 minutes later
    const now = new Date();
    const snoozeTime = new Date(now.getTime() + 9 * 60 * 1000);
    const snoozeHours = snoozeTime.getHours();
    const snoozeMinutes = snoozeTime.getMinutes();
    setAlarmTime(`${snoozeHours.toString().padStart(2, '0')}:${snoozeMinutes.toString().padStart(2, '0')}`);
  };

  const getTimeUntilAlarm = () => {
    if (!isAlarmEnabled) return null;
    const now = new Date();
    const [alarmHours, alarmMinutes] = alarmTime.split(':').map(Number);
    const alarm = new Date();
    alarm.setHours(alarmHours, alarmMinutes, 0, 0);

    if (alarm <= now) {
      alarm.setDate(alarm.getDate() + 1);
    }

    const diff = alarm.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m`;
  };

  if (isRinging) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-red-600 via-red-700 to-red-800 text-white p-8 animate-pulse">
        <div className="text-center space-y-8">
          <div className="animate-bounce">
            <Bell className="w-24 h-24 mx-auto text-yellow-300" />
          </div>
          <h1 className="text-6xl font-bold animate-pulse">ALARM!</h1>
          <p className="text-2xl">{formatTime(currentTime)}</p>
          {snoozeCount > 0 && (
            <p className="text-lg text-yellow-300">
              Snoozed {snoozeCount} time{snoozeCount > 1 ? 's' : ''}
            </p>
          )}
          <div className="space-y-4">
            <button
              onClick={stopAlarm}
              className="px-8 py-4 bg-white text-red-600 rounded-full text-xl font-semibold hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 mr-4"
            >
              Stop Alarm
            </button>
            <button
              onClick={snoozeAlarm}
              className="px-8 py-4 bg-yellow-500 text-white rounded-full text-xl font-semibold hover:bg-yellow-600 transition-all duration-200 transform hover:scale-105"
            >
              Snooze 9min
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white p-8">
      <div className="text-center space-y-8 max-w-sm w-full">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          Alarm Clock
        </h1>
        
        <div className="space-y-4">
          <div className="text-6xl font-mono font-bold transition-all duration-300">
            {formatTime(currentTime)}
          </div>
          <p className="text-white/70 text-lg">
            {formatDate(currentTime)}
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 space-y-4 transform transition-all duration-300 hover:bg-white/15">
          <div className="flex items-center justify-center space-x-2">
            <Clock className="w-5 h-5" />
            <span className="text-lg font-semibold">Alarm Time</span>
          </div>
          
          <div className="flex items-center justify-center space-x-4">
            <button
              onClick={() => adjustAlarmTime(-15)}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-all duration-200 hover:scale-110"
            >
              <Minus className="w-5 h-5" />
            </button>
            
            <div className="text-4xl font-mono font-bold min-w-[120px] transition-all duration-300">
              {alarmTime}
            </div>
            
            <button
              onClick={() => adjustAlarmTime(15)}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-all duration-200 hover:scale-110"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>

          <button
            onClick={() => setIsAlarmEnabled(!isAlarmEnabled)}
            className={`w-full py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 ${
              isAlarmEnabled 
                ? 'bg-green-500 hover:bg-green-600 text-white shadow-lg shadow-green-500/30' 
                : 'bg-white/20 hover:bg-white/30 text-white'
            }`}
          >
            {isAlarmEnabled ? (
              <div className="flex items-center justify-center space-x-2">
                <Volume2 className="w-5 h-5" />
                <span>Alarm On</span>
              </div>
            ) : (
              <div className="flex items-center justify-center space-x-2">
                <BellOff className="w-5 h-5" />
                <span>Alarm Off</span>
              </div>
            )}
          </button>

          {isAlarmEnabled && (
            <div className="text-white/70 text-center space-y-1 animate-fade-in">
              <p>Alarm in {getTimeUntilAlarm()}</p>
              {snoozeCount > 0 && (
                <p className="text-yellow-300 text-sm">
                  (Snoozed {snoozeCount} time{snoozeCount > 1 ? 's' : ''})
                </p>
              )}
            </div>
          )}
        </div>

        <p className="text-white/60 text-sm">
          Turn upside down for timer
        </p>
      </div>
    </div>
  );
}
