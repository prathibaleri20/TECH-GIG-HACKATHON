import { useState, useEffect } from 'react';

export type OrientationType = 'portrait-up' | 'portrait-down' | 'landscape-left' | 'landscape-right';

const getOrientation = (): OrientationType => {
  if (screen?.orientation) {
    const angle = screen.orientation.angle;
    if (angle === 0) return 'portrait-up';
    if (angle === 180) return 'portrait-down';
    if (angle === 90) return 'landscape-right';
    if (angle === 270 || angle === -90) return 'landscape-left';
  }
  
  // Fallback for browsers without screen.orientation
  const { innerWidth, innerHeight } = window;
  if (innerHeight > innerWidth) {
    return 'portrait-up'; // Default to upright when we can't detect rotation
  } else {
    return 'landscape-right'; // Default to right when we can't detect rotation
  }
};

export function useOrientation(): OrientationType {
  const [orientation, setOrientation] = useState<OrientationType>(() => {
    if (typeof window === 'undefined') return 'portrait-up';
    return getOrientation();
  });
    

  useEffect(() => {
    const handleOrientationChange = () => {
      // Small delay to ensure orientation data is updated
      setTimeout(() => {
        setOrientation(getOrientation());
      }, 100);
    };

    const handleResize = () => {
      setOrientation(getOrientation());
    };

    // Listen for orientation changes
    window.addEventListener('orientationchange', handleOrientationChange);
    window.addEventListener('resize', handleResize);
    
    // Listen for screen orientation changes (modern browsers)
    if (screen?.orientation) {
      screen.orientation.addEventListener('change', handleOrientationChange);
    }

    return () => {
      window.removeEventListener('orientationchange', handleOrientationChange);
      window.removeEventListener('resize', handleResize);
      if (screen?.orientation) {
        screen.orientation.removeEventListener('change', handleOrientationChange);
      }
    };
  }, []);

  return orientation;
}
