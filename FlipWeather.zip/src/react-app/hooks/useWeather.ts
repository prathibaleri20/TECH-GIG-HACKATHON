import { useState, useEffect } from 'react';
import { WeatherType } from '@/shared/types';

export function useWeather() {
  const [weather, setWeather] = useState<WeatherType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchWeather = async (lat?: number, lon?: number) => {
    try {
      setLoading(true);
      setError(null);
      
      let url = '/api/weather';
      if (lat && lon) {
        url += `?lat=${lat}&lon=${lon}`;
      }
      
      const response = await fetch(url);
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch weather');
      }
      
      setWeather(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          fetchWeather(position.coords.latitude, position.coords.longitude);
        },
        () => {
          // Fallback to default location if geolocation fails
          fetchWeather();
        }
      );
    } else {
      fetchWeather();
    }
  };

  useEffect(() => {
    getCurrentLocation();
  }, []);

  return { weather, loading, error, refetch: getCurrentLocation };
}
