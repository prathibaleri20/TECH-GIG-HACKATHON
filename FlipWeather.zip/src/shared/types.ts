import z from "zod";

export const WeatherSchema = z.object({
  location: z.string(),
  country: z.string(),
  temperature: z.number(),
  description: z.string(),
  icon: z.string(),
  humidity: z.number(),
  windSpeed: z.number(),
  feelsLike: z.number(),
});

export type WeatherType = z.infer<typeof WeatherSchema>;
