import { Hono } from "hono";

const app = new Hono<{ Bindings: Env }>();

app.use("/*", (c, next) => {
  c.header("Access-Control-Allow-Origin", "*");
  c.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  c.header("Access-Control-Allow-Headers", "Content-Type");
  return next();
});

app.get("/api/weather", async (c) => {
  try {
    const apiKey = c.env.OPENWEATHER_API_KEY;
    if (!apiKey) {
      return c.json({ error: "Weather API key not configured" }, 500);
    }

    // Validate API key format
    if (typeof apiKey !== 'string' || apiKey.trim() === '') {
      return c.json({ error: "Invalid weather API key" }, 500);
    }

    // Get user's location from query params or default to a major city
    const lat = c.req.query("lat") || "40.7128"; // NYC default
    const lon = c.req.query("lon") || "-74.0060";

    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`
    );

    if (!response.ok) {
      if (response.status === 401) {
        return c.json({ error: "Invalid weather API key. Please check your OpenWeatherMap API key." }, 401);
      }
      throw new Error(`Weather API error: ${response.status}`);
    }

    const weatherData = await response.json() as any;

    return c.json({
      location: weatherData.name,
      country: weatherData.sys.country,
      temperature: Math.round(weatherData.main.temp),
      description: weatherData.weather[0].description,
      icon: weatherData.weather[0].icon,
      humidity: weatherData.main.humidity,
      windSpeed: weatherData.wind.speed,
      feelsLike: Math.round(weatherData.main.feels_like),
    });
  } catch (error) {
    console.error("Weather API error:", error);
    return c.json({ error: "Failed to fetch weather data" }, 500);
  }
});

export default {
  fetch: app.fetch,
};
